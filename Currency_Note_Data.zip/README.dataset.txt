# Currency Note Detection > 2023-08-29 4:11pm
https://universe.roboflow.com/abhishek-nishad/currency-note-detection-hmfqa

Provided by a Roboflow user
License: CC BY 4.0

